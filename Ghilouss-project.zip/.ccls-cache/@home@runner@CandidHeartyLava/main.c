#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nom;
    char typepion[10];
    int x;
    int y;
    
} Piece;

typedef struct {
    char nom[20];
    int point;
    int numcoul;
    char plateau[11][11];
    Piece piece;
} Joueur;
void afficherTableauEchecs(Joueur x, Joueur y, char plateau[11][11]);

char demanderJeu() {
    char reponse;
    int m;
    m=0;
    while(reponse != 'o' && reponse != 'O' &&  reponse != 'n' && reponse != 'N' ){
    if (m>0){
      printf("réponse incorrecte\n");
    }
    printf("Voulez-vous jouer ? (o/n): ");
    scanf(" %c", &reponse);
    m++;
    }
    return reponse;
}

char demanderregles(){
  char regle;
    int t;
    t=0;
    while(regle != 'o' && regle != 'O' && regle != 'N' && regle != 'n' ){
    if (t>0){
      printf("réponse incorrecte\n");
    }
    printf("Voulez-vous l'affichage des regles ? (o/n): ");
    scanf(" %c", &regle);
    t++;
    }
    return regle;
}
Joueur creationdejoueur(int numcoul) {
    Joueur x;

    printf("Entrez le nom du joueur : ");
    scanf("%s", x.nom);

    if (numcoul == -1) {
        do {
            printf("Choisissez votre couleur (0 pour le blanc et 1 pour le noir) : ");
            scanf("%d", &x.numcoul);
            if (x.numcoul==0){
              printf("Votre couleur est le blanc\n");
                }
            else if (x.numcoul==1){
              printf("Votre couleur est le noir\n");
                }
            } while (x.numcoul != 0 && x.numcoul != 1);
    }
            else {
        x.numcoul = !numcoul;
        printf("Votre couleur est le %s\n", (x.numcoul == 0) ? "blanc" : "noir");
    }

    x.point = 40;
    memset(x.plateau, ' ', sizeof(x.plateau));
    return x;
}

Joueur achatdepiece(Joueur x, Joueur y) {
    Piece tour, fou, reine, cavalier, cavalier_fou,prince;
    const int TAILLE_PLATEAU=11;
    char continuer = 'o';
    char continuerr = 'o';
    char continue2 ='o';
    int prix;
    char b;
    char plateau[11][11];
    int k=0;
    int f;
    char nom2[50];
    int point2;
    Joueur numcoul;
    int numcoul2;
    int i,j;
  
    struct {
        char typepion[20];
    } a;

    // Initialisation du tableau d'échecs
    for (i = 0; i < 11; i++) {
        for (j = 0; j < 11; j++) {
            x.plateau[i][j] = 'A';
        }
    }
        // Placement des pièces fixes
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if ((i >= 0 && i < 4) ) {
                if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    x.plateau[i][j] = 'B';  // Pions
                }
                if ((i == 1 && j == 5)) {
                    x.plateau[i][j] = 'L';  // ROIS
                }
                
        }
          if ((i > 6 && i < TAILLE_PLATEAU)) {
            if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    x.plateau[i][j] = 'W';  // Pions
                }
                if ((i == TAILLE_PLATEAU - 2 && j == 5)) {
                    x.plateau[i][j] = 'R';  // ROIS
                }
    }
    }
    }
    while (continuer == 'o' || continuer == 'O' || continuerr == 'O' || continuerr == 'o') {
    printf("Entrez le nom de la pièce à acheter, joueur %s : ", x.nom);
    scanf("%s", a.typepion);
    f=0;
        if (strcmp(a.typepion, "REINE") == 0) {
            prix = 10;
            if (x.point >= prix) {
                printf("Vous possédez une reine.\n");
                x.point -= 10;
                printf("Points restants : %d\n", x.point);
                reine.x =0;
                reine.y = 0;
                if(x.numcoul == 0){
                  while (!((reine.x == 4 && reine.y == 6) || 
         (reine.x == 1 && (reine.y == 3 || reine.y == 5 || reine.y == 7 || reine.y == 9)) || 
         (reine.x == 2 && (reine.y == 4 || reine.y == 8)) || 
         (reine.x == 3 && (reine.y == 5 || reine.y == 7)))){ 
                if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre reine : ");
                scanf("%d", &reine.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre reine : ");
                scanf("%d", &reine.y);
                x.piece.nom = 'Q';
                    f++;

                    if( x.plateau[reine.x-1][reine.y-1] != 'A' ){ //---------------------------------  
                      reine.x=0;
                      reine.y=0;
                    }
                    
                  }
                }
                else if(x.numcoul == 1){
                  while( !((reine.x == 11 && (reine.y == 3 || reine.y == 5 || reine.y == 7 || reine.y == 9)) ||
    (reine.x == 10 && (reine.y == 4 || reine.y == 8)) ||
    (reine.x == 9 && (reine.y == 5 || reine.y == 7)) ||
    (reine.x == 8 && reine.y == 6))){
                if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre reine : ");
                scanf("%d", &reine.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre reine : ");
                scanf("%d", &reine.y);
                x.piece.nom = 'S';
                    f++;

                    if( x.plateau[reine.x-1][reine.y-1] != 'A' ){ //---------------------------------  
                      reine.x=0;
                      reine.y=0;
                    }
                    
                  }
                }  
                reine.x-=1;
                reine.y-=1;
                x.piece.x = reine.x;
                x.piece.y = reine.y;
                x.plateau[reine.x][reine.y] = x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);

            }else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "TOUR") == 0) {
            prix = 6;
            if (x.point >= prix) {
                printf("Vous possédez une tour.\n");
                x.point -= 6;
                printf("Points restants : %d\n", x.point);
                tour.x =0;
                tour.y = 0;
                if(x.numcoul == 0){
                  while (!((tour.x == 4 && tour.y == 6) || 
         (tour.x == 1 && (tour.y == 3 || tour.y == 5 || tour.y == 7 || tour.y == 9)) || 
         (tour.x == 2 && (tour.y == 4 || tour.y == 8)) || 
         (tour.x == 3 && (tour.y == 5 || tour.y == 7)))){ 
                  if(f>0){
                    printf("coordoonées invalides OU alors la case est deja occupée\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre tour : ");
                scanf("%d", &tour.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre tour : ");
                scanf("%d", &tour.y);
                x.piece.nom = 'T';
              
                  if( x.plateau[tour.x-1][tour.y-1] != 'A' ){ //---------------------------------  
                    tour.x=0;
                    tour.y=0;
                  }
                    
                    f++;
                
                    
                  }
                }
            
            
                else if(x.numcoul == 1){
  
                  while( !((tour.x == 11 && (tour.y == 3 || tour.y == 5 || tour.y == 7 || tour.y == 9)) ||(tour.x == 10 && (tour.y == 4 || tour.y == 8)) ||
    (tour.x == 9 && (tour.y == 5 || tour.y == 7)) ||
    (tour.x == 8 && tour.y == 6))){
                  if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre tour : ");
                scanf("%d", &tour.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre tour : ");
                scanf("%d", &tour.y);
                x.piece.nom = 'U';
                    f++;

                  if( x.plateau[tour.x-1][tour.y-1] != 'A' ){ //---------------------------------  
                    tour.x=0;
                    tour.y=0;
                  }
                    
                x.piece.nom = 'U';
                  }
                }
                tour.x-=1;
                tour.y-=1;
                x.piece.x = tour.x;
                x.piece.y = tour.y;
                x.plateau[tour.x][tour.y] = x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            } 
                else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
    
        }
          else if (strcmp(a.typepion, "FOU") == 0) {
            prix = 3;
            
            if (x.point >= prix) {
                printf("Vous possédez un fou.\n");
                 
                x.point -= 3;
                printf("Points restants : %d\n", x.point);
                fou.x =0;
                fou.y = 0;
                if(x.numcoul == 0){
                  while (!((fou.x == 4 && fou.y == 6) || 
         (fou.x == 1 && (fou.y == 3 || fou.y == 5 || fou.y == 7 || fou.y == 9)) || 
         (fou.x == 2 && (fou.y == 4 || fou.y == 8)) || 
         (fou.x == 3 && (fou.y == 5 || fou.y == 7)))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre fou : ");
                scanf("%d", &fou.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre fou : ");
                scanf("%d", &fou.y);
                x.piece.nom = 'F';
                    f++;

                  if( x.plateau[fou.x-1][fou.y-1] != 'A' ){ //---------------------------------  
                    fou.x=0;
                    fou.y=0;
                  }
                    
                  }}
                else if(x.numcoul == 1){
  
                  while( !((fou.x == 11 && (fou.y == 3 || fou.y == 5 || fou.y == 7 || fou.y == 9)) ||
    (fou.x == 10 && (fou.y == 4 || fou.y == 8)) ||
    (fou.x == 9 && (fou.y == 5 || fou.y == 7)) ||
    (fou.x == 8 && fou.y == 6))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre fou : ");
                scanf("%d", &fou.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre fou : ");
                scanf("%d", &fou.y);
                x.piece.nom = 'M';
                    f++;

                  if( x.plateau[fou.x-1][fou.y-1] != 'A' ){ //---------------------------------  
                    fou.x=0;
                    fou.y=0;
                  }
                    
                  }
                }
                
                fou.x-=1;
                fou.y-=1;
                x.piece.x = fou.x;
                x.piece.y = fou.y;
                x.plateau[fou.x][fou.y] = 'F';
                afficherTableauEchecs(x, y, x.plateau);
            } else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "CAVALIER") == 0) {
            prix = 3;
            if (x.point >= prix) {
                printf("Vous possédez un cavalier.\n");
                x.point -= 3;
                printf("Points restants : %d\n", x.point);
                cavalier.x =0;
                cavalier.y = 0;
                if(x.numcoul == 0){
                  while (!((cavalier.x == 4 && cavalier.y == 6) || 
         (cavalier.x == 1 && (cavalier.y == 3 || cavalier.y == 5 || cavalier.y == 7 || cavalier.y == 9)) || 
         (cavalier.x == 2 && (cavalier.y == 4 || cavalier.y == 8)) || 
         (cavalier.x == 3 && (cavalier.y == 5 || cavalier.y == 7)))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier : ");
                scanf("%d", &cavalier.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier : ");
                scanf("%d", &cavalier.y);
                x.piece.nom = 'C';
                    f++;

                  if( x.plateau[cavalier.x-1][cavalier.y-1] != 'A' ){ //---------------------------------
                    cavalier.x=0;
                    cavalier.y=0;
                  }
                    
                  }}
                  else if(x.numcoul == 1){
  
                  while( !((cavalier.x == 11 && (cavalier.y == 3 || cavalier.y == 5 || cavalier.y == 7 || cavalier.y == 9)) ||
    (cavalier.x == 10 && (cavalier.y == 4 || cavalier.y == 8)) ||
    (cavalier.x == 9 && (cavalier.y == 5 || cavalier.y == 7)) ||
    (cavalier.x == 8 && cavalier.y == 6))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier : ");
                scanf("%d", &cavalier.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier : ");
                scanf("%d", &cavalier.y);
                x.piece.nom = 'N';
                    f++;

                  if( x.plateau[cavalier.x-1][cavalier.y-1] != 'A' ){ //---------------------------------
                    cavalier.x=0;
                    cavalier.y=0;
                  }
                    
                  }
                }
                
                cavalier.x-=1;
                cavalier.y-=1;
                x.piece.x = cavalier.x;
                x.piece.y = cavalier.y;
                x.plateau[cavalier.x][cavalier.y] = 'C';
                afficherTableauEchecs(x, y, x.plateau);
            } else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "CAVALIER_FOU") == 0) {
            prix = 7;
            if (x.point >= prix) {
                printf("Vous possédez un cavalier fou.\n");
                x.point -= 7;
                printf("Points restants : %d\n", x.point);
                cavalier_fou.x =0;
                cavalier_fou.y = 0;
                if(x.numcoul == 0){
                  while (!((cavalier_fou.x == 4 && cavalier_fou.y == 6) || 
         (cavalier_fou.x == 1 && (cavalier_fou.y == 3 || cavalier_fou.y == 5 || cavalier_fou.y == 7 || cavalier_fou.y == 9)) || 
         (cavalier_fou.x == 2 && (cavalier_fou.y == 4 || cavalier_fou.y == 8)) || 
         (cavalier_fou.x == 3 && (cavalier_fou.y == 5 || cavalier_fou.y == 7)))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier fou : ");
                scanf("%d", &cavalier_fou.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier fou : ");
                scanf("%d", &cavalier_fou.y);
                x.piece.nom = 'K';
                    f++;

                  if( x.plateau[cavalier_fou.x-1][cavalier_fou.y-1] != 'A' ){ //-------------------------
                    cavalier_fou.x=0;
                    cavalier_fou.y=0;
                  }
                    
                  }}
              else if(x.numcoul == 1){
  
                  while( !((cavalier_fou.x == 11 && (cavalier_fou.y == 3 || cavalier_fou.y == 5 || cavalier_fou.y == 7 || cavalier_fou.y == 9)) ||
    (cavalier_fou.x == 10 && (cavalier_fou.y == 4 || cavalier_fou.y == 8)) ||
    (cavalier_fou.x == 9 && (cavalier_fou.y == 5 || cavalier_fou.y == 7)) ||
    (cavalier_fou.x == 8 && cavalier_fou.y == 6))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier fou : ");
                scanf("%d", &cavalier_fou.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier fou : ");
                scanf("%d", &cavalier_fou.y);
                x.piece.nom = 'V';
                    f++;

                  if( x.plateau[cavalier_fou.x-1][cavalier_fou.y-1] != 'A' ){ //-------------------------
                    cavalier_fou.x=0;
                    cavalier_fou.y=0;
                  }
                    
                  }
                }
                cavalier_fou.y-=1;
                cavalier_fou.x-=1;
                x.piece.x = cavalier_fou.x;
                x.piece.y = cavalier_fou.y;

                x.plateau[cavalier_fou.x][cavalier_fou.y] = 'K';
                afficherTableauEchecs(x, y, x.plateau);
            }
            else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } 
        else if (strcmp(a.typepion, "PRINCE") == 0) {
            prix = 6;
            if (x.point >= prix) {
                printf("Vous possédez un prince\n");
                x.point -= 6;
                printf("Points restants : %d\n", x.point);
                prince.x =0;
                prince.y = 0;
                if(x.numcoul == 0){
                  while (!((prince.x == 4 && prince.y == 6) || 
         (prince.x == 1 && (prince.y == 3 || prince.y == 5 || prince.y == 7 || prince.y == 9)) || 
         (prince.x == 2 && (prince.y == 4 || prince.y == 8)) || 
         (prince.x == 3 && (prince.y == 5 || prince.y == 7)))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre prince : ");
                scanf("%d", &prince.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre prince : ");
                scanf("%d", &prince.y);
                x.piece.nom = 'P';
                    f++;

                  if( x.plateau[prince.x-1][prince.y-1] != 'A' ){ //-------------------------
                    prince.x=0;
                    prince.y=0;
                  }
                    
                  }}
                else if(x.numcoul == 1){
  
                  while( !((prince.x == 11 && (prince.y == 3 || prince.y == 5 || prince.y == 7 || prince.y == 9)) ||
    (prince.x == 10 && (prince.y == 4 || prince.y == 8)) ||
    (prince.x == 9 && (prince.y == 5 || prince.y == 7)) ||
    (prince.x == 8 && prince.y == 6))){
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                printf("Entrer la ligne dans laquelle vous voulez placer votre prince : ");
                scanf("%d", &prince.x);
                printf("Entrer la colonne dans laquelle vous voulez placer votre prince : ");
                scanf("%d", &prince.y);
                x.piece.nom = 'O';
                    f++;

                  if( x.plateau[prince.x-1][prince.y-1] != 'A' ){ //-------------------------
                    prince.x=0;
                    prince.y=0;
                  }
                    
                  }
                }
                prince.x-=1;
                prince.y-=1;
                x.piece.x = prince.x;
                x.piece.y = prince.y;

                x.plateau[prince.x][prince.y] = 'P';
                afficherTableauEchecs(x, y, x.plateau);
            }else {
            printf("La pièce n'est pas valide.\n");
        }
              
          
    }   strcpy(nom2, x.nom); 
        strcpy(x.nom, y.nom);
        strcpy(y.nom, nom2); 
        k++;
        point2=x.point;
        x.point=y.point;
        y.point=point2;
        numcoul2=x.numcoul;
        x.numcoul=y.numcoul;
        y.numcoul=numcoul2;
       if(k>=2)  {
      do {printf("Voulez-vous continuer à acheter ? (o/n) joueur %s\t:",x.nom);
      scanf(" %c", &continuer);
         }while(!(continuer == 'O' || continuer == 'o' || continuer == 'n' || continuer == 'N'));
         if (continuer == 'n' || continuer == 'N'){
            strcpy(nom2, x.nom); 
            strcpy(x.nom, y.nom);
            strcpy(y.nom, nom2); 
            k++;
            point2=x.point;
            x.point=y.point;
            y.point=point2;
            numcoul2=x.numcoul;
            x.numcoul=y.numcoul;
            y.numcoul=numcoul2; 
            do {printf("Voulez-vous continuer à acheter ? (o/n) joueur %s\t:",x.nom);
              scanf(" %c", &continuerr);
         }while(!(continuerr == 'O' || continuerr == 'o' || continuerr == 'n' || continuerr == 'N'));
      }
       }
      
      }
      

      
      


  

    afficherTableauEchecs(x, y,x.plateau);

  int valeurx, valeury,ancvaleurx,ancvaleury;
  char nompiece[20];
  int Y=0;
  int e =0;

  
  while(continue2 == 'o' || continue2 == 'O'){
        ancvaleurx=0;
        ancvaleury=0;
      printf("numcoul du joueur %s:  %d",x.nom,x.numcoul);
      printf("quelle pièce voulez vous deplacer? Joueur %s\n :",x.nom);
      scanf("%s", &nompiece);
      do {
        printf("y= %d",Y);
        printf("quelles sont les coordoonées actuelles (ligne)");
        scanf("%d", &ancvaleurx);
        printf("quelles sont les coordoonées actuelles (colonne)");
        scanf("%d", &ancvaleury);
        ancvaleurx-=1;
        ancvaleury-=1;
        x.piece.x=ancvaleurx;
        x.piece.y=ancvaleury;
        if (strcmp(nompiece, "REINE") == 0){
          if (x.numcoul == 0 && x.plateau[ancvaleurx][ancvaleury] =='Q'){
            Y=0;
            
          }
          else if (x.numcoul == 1 && x.plateau[ancvaleurx][ancvaleury]=='S'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "TOUR") == 0){
          if (x.numcoul == 0 && x.plateau[ancvaleurx][ancvaleury] =='T'){
            Y=0;
          }
          else if (x.numcoul == 1 && x.plateau[ancvaleurx][ancvaleury] =='U'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "FOU") == 0){
          if (x.numcoul ==0 && x.plateau[ancvaleurx][ancvaleury]=='F'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='M'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "CAVALIER") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury] == 'C'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='N'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "CAVALIER_FOU") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='K'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='S'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "PRINCE") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='P'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='O'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        
      }while (Y ==20);
  
      do{
      if (strcmp(nompiece, "REINE")  == 0 ){
          if (x.numcoul==0 ){
            x.piece.nom='Q';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx)));;
          }
      else if (x.numcoul==1 ){
          x.piece.nom='S';  
        do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx)));;
          }
      }
        else if (strcmp(nompiece, "TOUR") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='T';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((valeury-ancvaleury==0 && valeurx-ancvaleurx!=0) || !(valeury-ancvaleury!=0 && valeurx-ancvaleurx==0)));
          }
          
          else if (x.numcoul== 1){
            x.piece.nom='U';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((valeury-ancvaleury==0 && valeurx-ancvaleurx!=0) ||(valeury-ancvaleury!=0 && valeurx-ancvaleurx==0)));
          }
      }
        else if (strcmp(nompiece, "FOU") == 0){
          if (x.numcoul==0){
            x.piece.nom='F';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!(((valeury-ancvaleury)%(valeurx-ancvaleurx)==1) ||(valeury-ancvaleury==0 && valeurx-ancvaleurx!=0)));
          }
          else if (x.numcoul==0 ){
            x.piece.nom='M';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!(((valeury-ancvaleury)%(valeurx-ancvaleurx)==1) ||(valeury-ancvaleury==0 && valeurx-ancvaleurx!=0)));
            
          }
      }
        else if (strcmp(nompiece, "CAVALIER") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='C';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(((valeury-ancvaleury==2)&&(valeurx-ancvaleurx==1) ||(valeury-ancvaleury==1) && (valeurx-ancvaleurx==2)));
          }
          else if (x.numcoul=0 ){
            x.piece.nom='N';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((valeury-ancvaleury==2)&&(valeurx-ancvaleurx==1) ||(valeury-ancvaleury==1) && (valeurx-ancvaleurx==2)));
          }
      }
        else if (strcmp(nompiece, "CAVALIER_FOU") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='K';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!(((valeury-ancvaleury)%(valeurx-ancvaleurx)==1) ||(valeury-ancvaleury==0 && valeurx-ancvaleurx!=0) ||((valeury-ancvaleury==2)&&(valeurx-ancvaleurx==1) ||(valeury-ancvaleury==1) && (valeurx-ancvaleurx==2))));
          }
          else if (x.numcoul==0 ){
            x.piece.nom='S';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!((valeury-ancvaleury)%(valeurx-ancvaleurx)==1) ||(valeury-ancvaleury==0 && valeurx-ancvaleurx!=0) ||((valeury-ancvaleury==2)&&(valeurx-ancvaleurx==1) ||(valeury-ancvaleury==1) && (valeurx-ancvaleurx==2)));
          }
      }
        else if (strcmp(nompiece, "PRINCE") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='P';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!(valeurx-ancvaleurx<=2)&&(valeury-ancvaleury<=2)&&(valeurx-ancvaleurx>0)&&(valeury-ancvaleury>0));
          }
          else if (x.numcoul==0 ){
            x.piece.nom='O';
            do{
              printf("quelles sont les nouvelles coordoonées (ligne)");
              scanf("%d", &valeurx);
              printf("quelles sont les nouvelles coordoonées (colonne)");
              scanf("%d", &valeury);
              valeurx-=1;
              valeury-=1;
              x.piece.x = valeurx;
              x.piece.y = valeury;
            }while(!(valeurx-ancvaleurx<=2)&&(valeury-ancvaleury<=2)&&(valeurx-ancvaleurx>0)&&(valeury-ancvaleury>0));
          }
      }
        }while(x.plateau[x.piece.x][x.piece.y]!='A');
      x.plateau[ancvaleurx][ancvaleury] = 'A';
      x.plateau[x.piece.x][x.piece.y]=x.piece.nom;
      afficherTableauEchecs(x, y,x.plateau);
      
      
      strcpy(nom2, x.nom); 
        strcpy(x.nom, y.nom);
        strcpy(y.nom, nom2); 
        e++;
        point2=x.point;
        x.point=y.point;
        y.point=point2;
        numcoul2=x.numcoul;
        x.numcoul=y.numcoul;
        y.numcoul=numcoul2;
       if(e>=2)  {
      printf("Voulez-vous continuer à déplacer des pièces ? (o/n) joueur %s\t:",x.nom);
      scanf(" %s", &continue2);
  }
  }

    return x;

}




void afficherCaseBlanche() {
    printf("\033[47m  "); // Afficher une case blanche
}

void afficherCaseNoire() {
    printf("\033[40m  "); // Afficher une case noire
}

void afficherCaseMarron() {
    printf("\033[48;2;139;69;19m  "); // Afficher une case marron
}

void afficherTableauEchecs(Joueur x, Joueur y, char plateau[11][11]) {
    const int TAILLE_PLATEAU = 11;
    int i, j;


    // Placement des pièces du joueur 1
   // plateau[x.piece.x][x.piece.y] = x.piece.nom;

    // Placement des pièces du joueur 2
   // plateau[y.piece.x][y.piece.y] = y.piece.nom;



    // Affichage du tableau d'échecs
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if (plateau[i][j] == 'W') {    
                printf("\033[40m\u2659 ");
            } else if (plateau[i][j] == 'R') {
                printf("\033[40m\u2654 ");  // Afficher une case noire avec le Roi
            } 
            else if (plateau[i][j] == 'B') {    
                printf("\033[40m\u265F ");
            } else if (plateau[i][j] == 'L') {
                printf("\033[40m\u265A ");  // Afficher une case noire avec le Roi
            }else if (plateau[i][j] == 'Q') {
                            printf("\033[40m\u2655 ");  // Reine blanche
                        }
              else if (plateau[i][j] == 'S') {
                            printf("\033[40m\u265B ");  // Reine noire
                        }
 
              else if (plateau[i][j] == 'C') {
                  printf("\033[40m\u2658 ");  // Cavalier blanc
      

}
              else if (plateau[i][j] == 'N') {
                  printf("\033[40m\u265E ");  // Cavalier noir

}
 else if (plateau[i][j] == 'K') {
     printf("\033[40m\u265D ");  // Cavalier fou blanc
            
}
else if (plateau[i][j] == 'V') {
   printf("\033[40m\u2657 ");  // Cavalier fou noir
            
}
else if (plateau[i][j] == 'T') {
  
                printf("\033[40m\u265C ");  // Tour blanche
}
else if (plateau[i][j] == 'U'){
                printf("\033[40m\u2656 ");  // Tour noire
            }


else if (plateau[i][j] == 'F') {   
          printf("\033[40m\u2657 ");  // Fou blanc
            
}
  else if (plateau[i][j] == 'M') {   
          printf("\033[40m\u265D ");  // Fou noir
            
}
else if (plateau[i][j] == 'P') {
      printf("\033[40m\U0001f934");  // Prince blanc
            

}
else if (plateau[i][j] == 'O') {
       printf("\033[40m\u265E ");  // Prince noir

}

            
            else {
                if ((i + j) % 2 == 0) {
                    afficherCaseBlanche();
                } else {
                    afficherCaseMarron();
                }
            }
          
        }
        printf("\033[0m\n"); // Réinitialiser la couleur
    }
}



int main() {
    char plateau[11][11];
    Joueur joueur1, joueur2;
    Piece a,b;
    const int TAILLE_PLATEAU = 11;
    int i, j;  
    char reponse= demanderJeu();
    char jouer = 'o';
    char regle= demanderregles();
    if (reponse == 'o' || reponse == 'O') {
      while (jouer == 'o' || jouer == 'O') {
        if (regle=='o'||regle=='O'){
          printf("L'echiquier fera une taille de 11 x 11.\n");
          printf("Pour gagner la partie, un joueur devra mettre en echec et mat le roi adverse.\n");
          printf("Le jeu sera en 1V1.\n");
          printf("La notation du jeu pourra etre soit au format officiel des echecs soit en indiquant les coordonnees des pieces deplacees.\n");
          printf("Le placement initial des pieces sera choisi par les joueurs lors de la phase de preparation.\n");
          printf("o Preparation de la partie:\n");
          printf("Chaque joueur possede 40 points.\n");
          printf("Ces points permettent aux joueurs d'acheter chacun leur tour les pieces voulues et de les placer ou ils le souhaitent dans sa zone de depart (voir schema).\n");
          printf("Les rois ne sont pas achetables et seront eux places a une place predefinie sur l'echiquier.\n");
          printf("En plus des rois, des pions seront egalement presents de base sur l'echiquier (voir schema).\n");
          printf("Les pieces disponibles sont les pieces du jeu classique ainsi que deux nouvelles pieces. il y a 4 pieces de chaque partagees par les deux equipes : Reine (10 points), Cavalier (3 points), Fou (3 points), Tour (5 points).\n");
          printf("Les deux nouvelles pieces sont: le Cavalier Fou (regle de deplacement combinant le Cavalier et le Fou) (7 points), et le Prince (se deplace comme le roi mais de 2 cases) (6 points).\n");
          printf("Quiconque peut appuyer sur sur 0 si il ne souhaite plus acheter de piece.\n");
          printf("Ce statut sera automatiquement attribue a un joueur ayant consomme tous ses points, ou que son nombre de points restants est trop faible pour acheter une nouvelle piece.\n");
          printf("Echec et mat:en cas de mort du roi.\n");
        }
            // Initialisation du tableau d'échecs
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            plateau[i][j] = ' ';
        }
    }
            // Placement des pièces fixes
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if ((i >= 0 && i < 4) ) {
                if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    plateau[i][j] = 'B';  // Pions
                }
                if ((i == 1 && j == 5)) {
                    plateau[i][j] = 'L';  // ROIS
                }
                
        }
          if ((i > 6 && i < TAILLE_PLATEAU)) {
            if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    plateau[i][j] = 'W';  // Pions
                }
                if ((i == TAILLE_PLATEAU - 2 && j == 5)) {
                    plateau[i][j] = 'R';  // ROIS
                }
    }
    }
    }
        afficherTableauEchecs(joueur1, joueur2, plateau);
        joueur1 = creationdejoueur(-1);
        joueur2 = creationdejoueur(joueur1.numcoul);
        
         achatdepiece(joueur1, joueur2);
        plateau[joueur1.piece.x][joueur1.piece.y]=joueur1.piece.nom;
        
        
         plateau[joueur2.piece.x][joueur2.piece.y]=joueur2.piece.nom;

        printf("Voulez-vous jouer de nouveau ? (o/n) ");
        scanf(" %c", &jouer);
    
    }
    }
    else if (reponse== 'n' || reponse=='N'){
      printf("ce n'est pas grave, la prochaine fois :/n");
    }

    return 0;
}
