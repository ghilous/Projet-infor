#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nom;
    char typepion[10];
    int x;
    int y;
    
} Piece;

typedef struct {
    char nom[20];
    int point;
    int numcoul;
    char plateau[11][11];
    Piece piece;
} Joueur;


char demanderJeu() ;
char demanderregles();
Joueur creationdejoueur(int numcoul);
Joueur deroulement_jeu(Joueur x, Joueur y);
void afficherTableauEchecs(Joueur x, Joueur y, char plateau[11][11]);
void includeFile(const char* filePath);