#include "header.h"


void vide_buffer(){
  while (getchar()!='\n'){}
}
char demanderJeu() { //demande au joueur si il veut jouer
    char reponse;
    int m;
    m=0;
    while(reponse != 'o' && reponse != 'O' &&  reponse != 'n' && reponse != 'N' ){
    if (m>0){
      printf("réponse incorrecte\n");
    }
    printf("Voulez-vous jouer ? (o/n): ");
    scanf(" %s", &reponse);
    m++;
    }
    return reponse;
}
void includeFile(const char* filePath) {
    FILE* fichier = fopen(filePath, "r"); // Ouvrir le fichier en mode lecture

    if (fichier != NULL) {
        int caractere;

        // Lire et afficher chaque caractère du fichier
        while ((caractere = fgetc(fichier)) != EOF) {
            putchar(caractere);
        }

        fclose(fichier); // Fermer le fichier
    } else {
        printf("Erreur lors de l'ouverture du fichier.\n");
    }
}
char demanderregles(){ //demande au joueur si il veut l'affichage 
  char regle;
    int t;
    t=0;
    while(regle != 'o' && regle != 'O' && regle != 'N' && regle != 'n' ){
    if (t>0){
      printf("réponse incorrecte\n");
    }
    printf("Voulez-vous l'affichage des regles ? (o/n): ");
    scanf(" %s", &regle);
    t++;
    }
    return regle;
}
Joueur creationdejoueur(int numcoul) { //crée le joueur demandé
    Joueur x;
    int verif;
    printf("Entrez le pseudo du joueur : ");
    scanf("%s", x.nom);

    if (numcoul == -1) {
        do{
          do {
            printf("Choisissez votre couleur (0 pour le blanc et 1 pour le noir) : ");
            verif =scanf("%d", &x.numcoul);
            vide_buffer();
        }while(verif!=1);
            if (x.numcoul==0){
              printf("Votre couleur est le blanc\n");
                }
            else if (x.numcoul==1){
              printf("Votre couleur est le noir\n");
                }
            if(x.numcoul != 0 || x.numcoul != 1){
              verif=0;
            }
            } while (!(x.numcoul == 0 || x.numcoul == 1));
    }
            else {
        x.numcoul = !numcoul;
        printf("Votre couleur est le %s\n", (x.numcoul == 0) ? "blanc" : "noir");
    }

    x.point = 40;
    memset(x.plateau, ' ', sizeof(x.plateau));
    return x;
}

Joueur deroulement_jeu(Joueur x, Joueur y) {  // permet  au joueur d'acheter des pièces et de les déplacer (tout le déroulement du jeu en soit)
    Piece tour, fou, reine, cavalier, cavalier_fou,prince;
    const int TAILLE_PLATEAU=11;
    char continuer = 'o';
    char continuerr = 'o';
    char continue2 ='o';
    int prix;
    char b;
    char plateau[11][11];
    int k=0;
    int f,r;
    char nom2[50];
    int point2;
    Joueur numcoul;
    int numcoul2;
    int i,j;
    int verif;
  
    struct {
        char typepion[20];
    } a;

    // Initialisation du tableau d'échecs
    for (i = 0; i < 11; i++) {
        for (j = 0; j < 11; j++) {
            x.plateau[i][j] = 'A';
        }
    }
        // Placement des pièces fixes
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if ((i >= 0 && i < 4) ) {
                if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    x.plateau[i][j] = 'B';  // Pions BLANCS
                }
                if ((i == 1 && j == 5)) {
                    x.plateau[i][j] = 'R';  // ROIS BLANCS
                }
                
        }
          if ((i > 6 && i < TAILLE_PLATEAU)) {
            if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    x.plateau[i][j] = 'W';  // Pions NOIRS
                }
                if ((i == TAILLE_PLATEAU - 2 && j == 5)) {
                    x.plateau[i][j] = 'L';  // ROIS NOIRS
                }
    }
    }
    }
    while (continuer == 'o' || continuer == 'O' || continuerr == 'O' || continuerr == 'o') {
      
    do{
      printf("Entrez le nom de la pièce à acheter, joueur %s : ", x.nom);  //demande au joueur quelle pièce acheter
    scanf("%s", a.typepion);
      if(!(strcmp(a.typepion, "REINE") == 0 ||strcmp(a.typepion, "TOUR") == 0 || strcmp(a.typepion, "FOU") == 0 || strcmp(a.typepion, "CAVALIER") == 0 || strcmp(a.typepion, "CAVALIER_FOU") == 0 || strcmp(a.typepion, "PRINCE") == 0)){
        printf("la pièce n'est pas valide\n");
      }
    }while(!(strcmp(a.typepion, "REINE") == 0 ||strcmp(a.typepion, "TOUR") == 0 || strcmp(a.typepion, "FOU") == 0 || strcmp(a.typepion, "CAVALIER") == 0 || strcmp(a.typepion, "CAVALIER_FOU") == 0 || strcmp(a.typepion, "PRINCE") == 0));
    f=0;
        if (strcmp(a.typepion, "REINE") == 0 ) { //si le joueur achète une pièce
            prix = 10;
            if (x.point >= prix) {
                printf("Vous possédez une reine.\n");
                x.point -= 10;
                printf("Points restants : %d\n", x.point);
                reine.x =0;
                reine.y = 0;
                if(x.numcoul == 0){ //si le joueur est blanc
                  while (!((reine.x == 4 && reine.y == 6) || 
         (reine.x == 1 && (reine.y == 3 || reine.y == 5 || reine.y == 7 || reine.y == 9)) || 
         (reine.x == 2 && (reine.y == 4 || reine.y == 8)) || 
         (reine.x == 3 && (reine.y == 5 || reine.y == 7)))){ //tant que la position est invalide, la nouvelle position de la reine noire est demandée
                if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre reine : ");
                verif=scanf("%d", &reine.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre reine : ");
                verif=scanf("%d", &reine.y);
                vide_buffer();
                }while (verif!=1);

                x.piece.nom = 'Q';
                    f++;

                    if( x.plateau[reine.x-1][reine.y-1] != 'A' ){ //---------------------------------  
                      reine.x=0;
                      reine.y=0;
                    }
                    
                  }
                }
                else if(x.numcoul == 1){  //si le joueur est noir
                  while( !((reine.x == 11 && (reine.y == 3 || reine.y == 5 || reine.y == 7 || reine.y == 9)) ||
    (reine.x == 10 && (reine.y == 4 || reine.y == 8)) ||
    (reine.x == 9 && (reine.y == 5 || reine.y == 7)) ||
    (reine.x == 8 && reine.y == 6))){   //tant que la position est invalide, la nouvelle position de la reine noire est demandée
                if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre reine : ");
                verif=scanf("%d", &reine.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre reine : ");
                verif=scanf("%d", &reine.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'S';
                    f++;

                    if( x.plateau[reine.x-1][reine.y-1] != 'A' ){ //---------------------------------  
                      reine.x=0;
                      reine.y=0;
                    }
                    
                  }
                }  
                reine.x-=1;
                reine.y-=1;
                x.piece.x = reine.x;
                x.piece.y = reine.y;
                x.plateau[reine.x][reine.y] = x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);

            }else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "TOUR") == 0) { //si le joueur achète une tour
            prix = 6;
            if (x.point >= prix) {
                printf("Vous possédez une tour.\n");
                x.point -= 6;
                printf("Points restants : %d\n", x.point);
                tour.x =0;
                tour.y = 0;
                if(x.numcoul == 0){ //si le joueur est blanc
                  while (!((tour.x == 4 && tour.y == 6) || 
         (tour.x == 1 && (tour.y == 3 || tour.y == 5 || tour.y == 7 || tour.y == 9)) || 
         (tour.x == 2 && (tour.y == 4 || tour.y == 8)) || 
         (tour.x == 3 && (tour.y == 5 || tour.y == 7)))){ //tant que la position est invalide, la nouvelle position de la tour blanche est demandée
                  if(f>0){
                    printf("coordoonées invalides OU alors la case est deja occupée\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre tour : ");
                verif=scanf("%d", &tour.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre tour : ");
                verif=scanf("%d", &tour.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'T';
              
                  if( x.plateau[tour.x-1][tour.y-1] != 'A' ){ //---------------------------------  
                    tour.x=0;
                    tour.y=0;
                  }
                    
                    f++;
                
                    
                  }
                }
            
            
                else if(x.numcoul == 1){ //si le joueur est noir
  
                  while( !((tour.x == 11 && (tour.y == 3 || tour.y == 5 || tour.y == 7 || tour.y == 9)) ||(tour.x == 10 && (tour.y == 4 || tour.y == 8)) ||
    (tour.x == 9 && (tour.y == 5 || tour.y == 7)) ||
    (tour.x == 8 && tour.y == 6))){     //tant que la position est invalide, la nouvelle position de la tour noire est demandée
                  if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre tour : ");
                verif=scanf("%d", &tour.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre tour : ");
                verif=scanf("%d", &tour.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'U';
                    f++;

                  if( x.plateau[tour.x-1][tour.y-1] != 'A' ){ //---------------------------------  
                    tour.x=0;
                    tour.y=0;
                  }
                    
                x.piece.nom = 'U';
                  }
                }
                tour.x-=1;
                tour.y-=1;
                x.piece.x = tour.x;
                x.piece.y = tour.y;
                x.plateau[tour.x][tour.y] = x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            } 
                else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
    
        }
          else if (strcmp(a.typepion, "FOU") == 0) { //si le joueur achète un fou
            prix = 3;
            
            if (x.point >= prix) {
                printf("Vous possédez un fou.\n");
                 
                x.point -= 3;
                printf("Points restants : %d\n", x.point);
                fou.x =0;
                fou.y = 0;
                if(x.numcoul == 0){    //si le joueur est blanc
                  while (!((fou.x == 4 && fou.y == 6) || 
         (fou.x == 1 && (fou.y == 3 || fou.y == 5 || fou.y == 7 || fou.y == 9)) || 
         (fou.x == 2 && (fou.y == 4 || fou.y == 8)) || 
         (fou.x == 3 && (fou.y == 5 || fou.y == 7)))){   //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre fou : ");
                verif=scanf("%d", &fou.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre fou : ");
                verif=scanf("%d", &fou.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'F';
                    f++;

                  if( x.plateau[fou.x-1][fou.y-1] != 'A' ){ //---------------------------------  
                    fou.x=0;
                    fou.y=0;
                  }
                    
                  }}
                else if(x.numcoul == 1){ //si le joueur est noir
  
                  while( !((fou.x == 11 && (fou.y == 3 || fou.y == 5 || fou.y == 7 || fou.y == 9)) ||
    (fou.x == 10 && (fou.y == 4 || fou.y == 8)) ||
    (fou.x == 9 && (fou.y == 5 || fou.y == 7)) ||
    (fou.x == 8 && fou.y == 6))){   //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre fou : ");
                verif=scanf("%d", &fou.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre fou : ");
                verif=scanf("%d", &fou.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'M';
                    f++;

                  if( x.plateau[fou.x-1][fou.y-1] != 'A' ){ //---------------------------------  
                    fou.x=0;
                    fou.y=0;
                  }
                    
                  }
                }
                
                fou.x-=1;
                fou.y-=1;
                x.piece.x = fou.x;
                x.piece.y = fou.y;
                x.plateau[fou.x][fou.y] =  x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            } else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "CAVALIER") == 0) { //si le joueur achète un cavalier
            prix = 3;
            if (x.point >= prix) {
                printf("Vous possédez un cavalier.\n");
                x.point -= 3;
                printf("Points restants : %d\n", x.point);
                cavalier.x =0;
                cavalier.y = 0;
                if(x.numcoul == 0){ //si le joueur est blanc
                  while (!((cavalier.x == 4 && cavalier.y == 6) || 
         (cavalier.x == 1 && (cavalier.y == 3 || cavalier.y == 5 || cavalier.y == 7 || cavalier.y == 9)) || 
         (cavalier.x == 2 && (cavalier.y == 4 || cavalier.y == 8)) || 
         (cavalier.x == 3 && (cavalier.y == 5 || cavalier.y == 7)))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier : ");
                verif=scanf("%d", &cavalier.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier : ");
                verif=scanf("%d", &cavalier.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'C';
                    f++;

                  if( x.plateau[cavalier.x-1][cavalier.y-1] != 'A' ){ //---------------------------------
                    cavalier.x=0;
                    cavalier.y=0;
                  }
                    
                  }}
                  else if(x.numcoul == 1){   //si le joueur est noir
  
                  while( !((cavalier.x == 11 && (cavalier.y == 3 || cavalier.y == 5 || cavalier.y == 7 || cavalier.y == 9)) ||
    (cavalier.x == 10 && (cavalier.y == 4 || cavalier.y == 8)) ||
    (cavalier.x == 9 && (cavalier.y == 5 || cavalier.y == 7)) ||
    (cavalier.x == 8 && cavalier.y == 6))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier : ");
                verif=scanf("%d", &cavalier.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier : ");
                verif=scanf("%d", &cavalier.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'N';
                    f++;

                  if( x.plateau[cavalier.x-1][cavalier.y-1] != 'A' ){ //---------------------------------
                    cavalier.x=0;
                    cavalier.y=0;
                  }
                    
                  }
                }
                
                cavalier.x-=1;
                cavalier.y-=1;
                x.piece.x = cavalier.x;
                x.piece.y = cavalier.y;
                x.plateau[cavalier.x][cavalier.y] =  x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            } else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } else if (strcmp(a.typepion, "CAVALIER_FOU") == 0) { //si le joueur achète un cavalier fou
            prix = 7;
            if (x.point >= prix) {
                printf("Vous possédez un cavalier fou.\n");
                x.point -= 7;
                printf("Points restants : %d\n", x.point);
                cavalier_fou.x =0;
                cavalier_fou.y = 0;
                if(x.numcoul == 0){        //si le joueur est blanc
                  while (!((cavalier_fou.x == 4 && cavalier_fou.y == 6) || 
         (cavalier_fou.x == 1 && (cavalier_fou.y == 3 || cavalier_fou.y == 5 || cavalier_fou.y == 7 || cavalier_fou.y == 9)) || 
         (cavalier_fou.x == 2 && (cavalier_fou.y == 4 || cavalier_fou.y == 8)) || 
         (cavalier_fou.x == 3 && (cavalier_fou.y == 5 || cavalier_fou.y == 7)))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier fou : ");
                verif=scanf("%d", &cavalier_fou.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier fou : ");
                verif=scanf("%d", &cavalier_fou.y);
                vide_buffer();
                }while (verif!=1);
                scanf("%d", &cavalier_fou.y);
                x.piece.nom = 'K';
                    f++;

                  if( x.plateau[cavalier_fou.x-1][cavalier_fou.y-1] != 'A' ){ //-------------------------
                    cavalier_fou.x=0;
                    cavalier_fou.y=0;
                  }
                    
                  }}
              else if(x.numcoul == 1){         //si le joueur est noir
  
                  while( !((cavalier_fou.x == 11 && (cavalier_fou.y == 3 || cavalier_fou.y == 5 || cavalier_fou.y == 7 || cavalier_fou.y == 9)) ||
    (cavalier_fou.x == 10 && (cavalier_fou.y == 4 || cavalier_fou.y == 8)) ||
    (cavalier_fou.x == 9 && (cavalier_fou.y == 5 || cavalier_fou.y == 7)) ||
    (cavalier_fou.x == 8 && cavalier_fou.y == 6))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre cavalier fou : ");
                verif=scanf("%d", &cavalier_fou.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre cavalier fou : ");
                verif=scanf("%d", &cavalier_fou.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'V';
                    f++;

                  if( x.plateau[cavalier_fou.x-1][cavalier_fou.y-1] != 'A' ){ //-------------------------
                    cavalier_fou.x=0;
                    cavalier_fou.y=0;
                  }
                    
                  }
                }
                cavalier_fou.y-=1;
                cavalier_fou.x-=1;
                x.piece.x = cavalier_fou.x;
                x.piece.y = cavalier_fou.y;

                x.plateau[cavalier_fou.x][cavalier_fou.y] =  x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            }
            else {
                printf("Vous n'avez pas assez de points pour effectuer cet achat.\n");
            }
        } 
        else if (strcmp(a.typepion, "PRINCE") == 0) { //si le joueur achète un prince
            prix = 6;
            if (x.point >= prix) {
                printf("Vous possédez un prince\n");
                x.point -= 6;
                printf("Points restants : %d\n", x.point);
                prince.x =0;
                prince.y = 0;
                if(x.numcoul == 0){   //si le joueur est blanc
                  while (!((prince.x == 4 && prince.y == 6) || 
         (prince.x == 1 && (prince.y == 3 || prince.y == 5 || prince.y == 7 || prince.y == 9)) || 
         (prince.x == 2 && (prince.y == 4 || prince.y == 8)) || 
         (prince.x == 3 && (prince.y == 5 || prince.y == 7)))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre prince : ");
                verif=scanf("%d", &prince.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre prince : ");
                verif=scanf("%d", &prince.y);
                vide_buffer();
                }while (verif!=1);
                x.piece.nom = 'P';
                    f++;

                  if( x.plateau[prince.x-1][prince.y-1] != 'A' ){ //-------------------------
                    prince.x=0;
                    prince.y=0;
                  }
                    
                  }}
                else if(x.numcoul == 1){   //si le joueur est noir
  
                  while( !((prince.x == 11 && (prince.y == 3 || prince.y == 5 || prince.y == 7 || prince.y == 9)) ||
    (prince.x == 10 && (prince.y == 4 || prince.y == 8)) ||
    (prince.x == 9 && (prince.y == 5 || prince.y == 7)) ||
    (prince.x == 8 && prince.y == 6))){ //tant que la position est invalide, la position est demandée
                    if(f>0){
                    printf("coordoonées invalides\n");
                  }
                do{
                  printf("Entrer la ligne dans laquelle vous voulez placer votre prince : ");
                verif=scanf("%d", &prince.x);
                vide_buffer();
                }while (verif!=1);
                do{
                  printf("Entrer la colonne dans laquelle vous voulez placer votre prince : ");
                verif=scanf("%d", &prince.y);
                vide_buffer();
                }while (verif!=1);
                scanf("%d", &prince.y);
                x.piece.nom = 'O';
                    f++;

                  if( x.plateau[prince.x-1][prince.y-1] != 'A' ){ //-------------------------
                    prince.x=0;
                    prince.y=0;
                  }
                    
                  }
                }
                prince.x-=1;
                prince.y-=1;
                x.piece.x = prince.x;
                x.piece.y = prince.y;

                x.plateau[prince.x][prince.y] =  x.piece.nom;
                afficherTableauEchecs(x, y, x.plateau);
            }
              
          
    } 
      strcpy(nom2, x.nom); 
        strcpy(x.nom, y.nom);
        strcpy(y.nom, nom2); 
        k++;
        point2=x.point;
        x.point=y.point;
        y.point=point2;
        numcoul2=x.numcoul;
        x.numcoul=y.numcoul;
        y.numcoul=numcoul2;
       if(k>=2)  {
      do {
      printf("Voulez-vous continuer à acheter ? (o/n) joueur %s\t:",x.nom);
      scanf(" %s", &continuer);
         }while(!(continuer == 'O' || continuer == 'o' || continuer == 'n' || continuer == 'N'));
         if (continuer == 'n' || continuer == 'N'){
            strcpy(nom2, x.nom); 
            strcpy(x.nom, y.nom);
            strcpy(y.nom, nom2); 
            k++;
            point2=x.point;
            x.point=y.point;
            y.point=point2;
            numcoul2=x.numcoul;
            x.numcoul=y.numcoul;
            y.numcoul=numcoul2; 
            do {
              printf("Voulez-vous continuer à acheter ? (o/n) joueur %s\t:",x.nom);
              scanf(" %s", &continuerr);
         }while(!(continuerr == 'O' || continuerr == 'o' || continuerr == 'n' || continuerr == 'N'));
      }
       }
      
      }
      

      strcpy(nom2, x.nom); 
            strcpy(x.nom, y.nom);
            strcpy(y.nom, nom2); 
            k++;
            point2=x.point;
            x.point=y.point;
            y.point=point2;
            numcoul2=x.numcoul;
            x.numcoul=y.numcoul;
            y.numcoul=numcoul2; 
      


  

    afficherTableauEchecs(x, y,x.plateau);

  int valeurx, valeury,ancvaleurx,ancvaleury;
  char nompiece[20];
  int Y=0;
  int e =0;

  
  while(continue2 == 'o' || continue2 == 'O'){
        ancvaleurx=0;
        ancvaleury=0;
      printf("quelle pièce voulez vous deplacer? Joueur %s\n :",x.nom);
      scanf("%s", &nompiece);
      do {
        do{
        printf("quelles sont les coordoonées actuelles (ligne)");
        verif=scanf("%d", &ancvaleurx);
                vide_buffer();
                }while (verif!=1);
        do{
          printf("quelles sont les coordoonées actuelles (colonne)");
          verif=scanf("%d", &ancvaleury);
                vide_buffer();
                }while (verif!=1);
        
        ancvaleurx-=1;
        ancvaleury-=1;
        x.piece.x=ancvaleurx;
        x.piece.y=ancvaleury;
        if (strcmp(nompiece, "REINE") == 0){
          if (x.numcoul == 0 && x.plateau[ancvaleurx][ancvaleury] =='Q'){
            Y=0;
            
          }
          else if (x.numcoul == 1 && x.plateau[ancvaleurx][ancvaleury]=='S'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "TOUR") == 0){
          if (x.numcoul == 0 && x.plateau[ancvaleurx][ancvaleury] =='T'){
            Y=0;
          }
          else if (x.numcoul == 1 && x.plateau[ancvaleurx][ancvaleury] =='U'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "FOU") == 0){
          if (x.numcoul ==0 && x.plateau[ancvaleurx][ancvaleury]=='F'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='M'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "CAVALIER") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury] == 'C'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='N'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "CAVALIER_FOU") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='K'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='S'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "PRINCE") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='P'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='O'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "ROI") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='R'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='L'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        else if (strcmp(nompiece, "PION") == 0){
          if (x.numcoul==0 && x.plateau[ancvaleurx][ancvaleury]=='B'){
            Y=0;
          }
          else if (x.numcoul==1 && x.plateau[ancvaleurx][ancvaleury]=='W'){
            Y=0;
          }
          else{
          Y=20;
        }
      }
        
      }while (Y ==20);
  
      
      if (strcmp(nompiece, "REINE")  == 0 ){
          if (x.numcoul==0 ){
            x.piece.nom='Q';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
             do{
               printf("quelles sont les nouvelles coordoonées (colonne): ");
              verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx))){
                  valeurx=0;
                  valeury=0;
              }
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B' );
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W' ){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='Q';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='Q';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='Q';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
          
            }while(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx)));
          }
          
      else if (x.numcoul==1 ){
          x.piece.nom='S';  
        do{
          do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
            
              valeurx-=1;
              valeury-=1;
              if(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx))){
                  valeurx=-1;
                  valeury=-1;
              }
            
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
          
                if (x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='S';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='S';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='S';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeury-ancvaleury) == abs(valeurx-ancvaleurx)) || (valeury==ancvaleury && valeurx!=ancvaleurx) || (valeury!=ancvaleury && valeurx==ancvaleurx)));;
          }
      }
        else if (strcmp(nompiece, "TOUR") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='T';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!( (abs(valeury-ancvaleury)>=0 && abs(valeurx-ancvaleurx==0) || abs(valeurx-ancvaleurx)>=0 && abs(valeury-ancvaleury)==0))){
                  valeurx=-2;
                  valeury=-2;
              }
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
              x.piece.x = valeurx;
              x.piece.y = valeury;
              
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='T';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='T';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='T';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!( (abs(valeury-ancvaleury)>=0 && abs(valeurx-ancvaleurx==0) || abs(valeurx-ancvaleurx)>=0 && abs(valeury-ancvaleury)==0)));
          }
          
          else if (x.numcoul== 1){
            x.piece.nom='U';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!( (abs(valeury-ancvaleury)>=0 && abs(valeurx-ancvaleurx==0) || abs(valeurx-ancvaleurx)>=0 && abs(valeury-ancvaleury)==0))){
                  valeurx=-3;
                  valeury=-3;
              }
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
              
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='U';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='U';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='U';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeury-ancvaleury)>=0 && valeurx-ancvaleurx==0) || (abs(valeurx-ancvaleurx)>=0 && valeury-ancvaleury==0)));
          }
      }
        else if (strcmp(nompiece, "FOU") == 0){
          if (x.numcoul==0){
            x.piece.nom='F';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
              if(!(abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury))){
                  valeurx=-4;
                  valeury=-4;
              }
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='F';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='F';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='F';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!(abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='M';
            do{
               do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                 if(!(abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury))){
                  valeurx=-5;
                  valeury=-5;
              }
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='M';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='M';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='M';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!(abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)));
            
          }
      }
        else if (strcmp(nompiece, "CAVALIER") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='C';
            do{
              do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1) || (abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2))){
                  valeurx=-6;
                  valeury=-6;
              }
              
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
                x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='C';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='C';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='C';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1) || (abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2)));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='N';
            do{
               do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                 if(!((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1) || (abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2))){
                  valeurx=-7;
                  valeury=-7;
              }
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='N';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='N';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='N';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1) || (abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2)));
          }
      }
        else if (strcmp(nompiece, "CAVALIER_FOU") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='K';
            do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
              if(!((abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)) || ((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1)) || ((abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2)))){
                  valeurx=-8;
                  valeury=-8;
              }
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
            x.piece.x = valeurx;
              x.piece.y = valeury;
            
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='K';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='K';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='K';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }while(!((abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)) || ((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1)) || ((abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2))));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='V';
            do{
              do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)) || ((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1)) || ((abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2)))){
                  valeurx=-9;
                  valeury=-9;
              }
              
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='V';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='V';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='V';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeurx-ancvaleurx) == abs(valeury-ancvaleury)) || ((abs(valeury-ancvaleury)==2)&&(abs(valeurx-ancvaleurx)==1)) || ((abs(valeury-ancvaleury)==1) && (abs(valeurx-ancvaleurx)==2))));
          }
      }
        else if (strcmp(nompiece, "PRINCE") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='P';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeurx-ancvaleurx) <= 2) && (abs(valeury-ancvaleury) <= 2))){
                  valeurx=-10;
                  valeury=-10;
              }
              
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='P';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='P';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='P';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeurx-ancvaleurx) <= 2) && (abs(valeury-ancvaleury) <= 2)));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='O';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeurx-ancvaleurx) <= 2) && (abs(valeury-ancvaleury) <= 2))){
                  valeurx=-11;
                  valeury=-11;
              }
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
              
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='O';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='O';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='O';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeurx-ancvaleurx) <= 2) && (abs(valeury-ancvaleury) <= 2)));
          }
      }
      else if (strcmp(nompiece, "ROI") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='R';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeurx-ancvaleurx) <= 1) && (abs(valeury-ancvaleury) <= 1))){
                  valeurx=-12;
                  valeury=-12;
              }
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
              x.piece.x = valeurx;
              x.piece.y = valeury;
              
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='P';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='R';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='R';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeurx-ancvaleurx) <= 1) && (abs(valeury-ancvaleury) <= 1)));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='L';
            do{
              do{
             do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((abs(valeurx-ancvaleurx) <= 1) && (abs(valeury-ancvaleury) <= 1))){
                  valeurx=-13;
                  valeury=-13;
              }
              
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='L';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='L';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
              exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='L';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((abs(valeurx-ancvaleurx) <= 1) && (abs(valeury-ancvaleury) <= 1)));
          }
      }
      else if (strcmp(nompiece, "PION") == 0){
          if (x.numcoul==0 ){
            x.piece.nom='B';
            do{
              do{
              do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((valeurx-ancvaleurx == 1) && (valeury-ancvaleury == 0) && (x.plateau[valeurx][valeury] == 'A')) ||
         ((valeurx-ancvaleurx == 1) && (abs(valeury-ancvaleury) == 1) && (x.plateau[valeurx][valeury] != 'A'))){
                  valeurx=-14;
                  valeury=-14;
              }
              
                }while(x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B');
              x.piece.x = valeurx;
              x.piece.y = valeury;
                if (x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='B';
              
            }
             if(x.plateau[valeurx][valeury]=='L'){
               x.plateau[valeurx][valeury]='B';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
               exit(7);
            }
            else{
              x.plateau[valeurx][valeury]='B';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((valeurx-ancvaleurx == 1) && (valeury-ancvaleury == 0) && (x.plateau[valeurx][valeury] == 'A')) ||
         ((valeurx-ancvaleurx == 1) && (abs(valeury-ancvaleury) == 1) && (x.plateau[valeurx][valeury] != 'A')));
          }
          else if (x.numcoul==1 ){
            x.piece.nom='W';
            do{
              do{
                do{
                printf("quelles sont les nouvelles coordoonées (ligne): ");
                verif=scanf("%d", &valeurx);
                vide_buffer();
                }while (verif!=1);
          do{
              printf("quelles sont les nouvelles coordoonées (colonne): ");
                verif=scanf("%d", &valeury);
                vide_buffer();
                }while (verif!=1);
              valeurx-=1;
              valeury-=1;
                if(!((valeurx-ancvaleurx == 1) && (valeury-ancvaleury == 0) && (x.plateau[valeurx][valeury] == 'A')) ||
         ((valeurx-ancvaleurx == 1) && (abs(valeury-ancvaleury) == 1) && (x.plateau[valeurx][valeury] != 'A'))){
                  valeurx=-14;
                  valeury=-14;
              }
              
                }while(x.plateau[valeurx][valeury]=='S' ||x.plateau[valeurx][valeury]=='U' ||x.plateau[valeurx][valeury]=='M' ||x.plateau[valeurx][valeury]=='N' ||x.plateau[valeurx][valeury]=='V' ||x.plateau[valeurx][valeury]=='J'||x.plateau[valeurx][valeury]=='W');
              x.piece.x = valeurx;
              x.piece.y = valeury;
              
                if (x.plateau[valeurx][valeury]=='R' ||x.plateau[valeurx][valeury]=='Q' ||x.plateau[valeurx][valeury]=='T' ||x.plateau[valeurx][valeury]=='F' ||x.plateau[valeurx][valeury]=='C' ||x.plateau[valeurx][valeury]=='K' ||x.plateau[valeurx][valeury]=='P'||x.plateau[valeurx][valeury]=='B'){
              
              x.plateau[ancvaleurx][ancvaleury]='A';
              x.plateau[valeurx][valeury]='W';
              
            }
             if(x.plateau[valeurx][valeury]=='R'){
               x.plateau[valeurx][valeury]='W';
              x.plateau[ancvaleurx][ancvaleury]='A';
              afficherTableauEchecs(x, y, x.plateau);
              printf("echec et mat et victoire du joueur %s\n",x.nom);
               exit (7);
            }
            else{
              x.plateau[valeurx][valeury]='W';
              x.plateau[ancvaleurx][ancvaleury]='A';
            }
            }while(!((valeurx-ancvaleurx == 1) && (valeury-ancvaleury == 0) && (x.plateau[valeurx][valeury] == 'A')) ||
         ((valeurx-ancvaleurx == 1) && (abs(valeury-ancvaleury) == 1) && (x.plateau[valeurx][valeury] != 'A')));
          }
      }

      x.plateau[ancvaleurx][ancvaleury] = 'A';
      x.plateau[x.piece.x][x.piece.y]=x.piece.nom;
      afficherTableauEchecs(x, y,x.plateau);
      
      
      strcpy(nom2, x.nom); 
        strcpy(x.nom, y.nom);
        strcpy(y.nom, nom2); 
        e++;
        point2=x.point;
        x.point=y.point;
        y.point=point2;
        numcoul2=x.numcoul;
        x.numcoul=y.numcoul;
        y.numcoul=numcoul2;
       if(e>=2)  {
      printf("Voulez-vous continuer à déplacer des pièces ? (o/n) joueur %s\t:",x.nom);
      scanf(" %s", &continue2);
  }
  
  }
    return x;

}




void afficherCaseBlanche() {
    printf("\033[47m  "); // Afficher une case blanche
}

void afficherCaseNoire() {
    printf("\033[40m  "); // Afficher une case noire
}

void afficherCaseMarron() {
    printf("\033[48;2;139;69;19m  "); // Afficher une case marron
}

void afficherTableauEchecs(Joueur x, Joueur y, char plateau[11][11]) {
    const int TAILLE_PLATEAU = 11;
    int i, j;

  system("clear");


    // Affichage du tableau d'échecs
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if (plateau[i][j] == 'W') {    
                printf("\033[40m\u2659 ");
            } else if (plateau[i][j] == 'R') {
                printf("\033[40m\u265A ");  // Afficher un Roi blanc
            } 
            else if (plateau[i][j] == 'B') {    
                printf("\033[40m\u265F ");
            } else if (plateau[i][j] == 'L') {
                printf("\033[40m\u2654 ");  // Afficher un  Roi noir
            }else if (plateau[i][j] == 'Q') {
                            printf("\033[40m\u265B ");  // Reine blanche
                        }
              else if (plateau[i][j] == 'S') {
                            printf("\033[40m\u2655 ");  // Reine noire
                        }
 
              else if (plateau[i][j] == 'C') {
                  printf("\033[40m\u265E ");  // Cavalier blanc
      

}
              else if (plateau[i][j] == 'N') {
                  printf("\033[40m\u2658 ");  // Cavalier noir

}
 else if (plateau[i][j] == 'K') {
     printf("\033[40m\u2022 ");  // Cavalier fou blanc
            
}
else if (plateau[i][j] == 'V') {
   printf("\033[40m\u25E6 ");  // Cavalier fou noir
            
}
else if (plateau[i][j] == 'T') {
  
                printf("\033[40m\u265C ");  // Tour blanche
}
else if (plateau[i][j] == 'U'){
                printf("\033[40m\u2656 ");  // Tour noire
            }


else if (plateau[i][j] == 'F') {   
          printf("\033[40m\u265D ");  // Fou blanc
            
}
  else if (plateau[i][j] == 'M') {   
          printf("\033[40m\u2657 ");  // Fou noir
            
}
else if (plateau[i][j] == 'P') {
      printf("\033[40m\U0001F7C2 ");  // Prince blanc
            

}
else if (plateau[i][j] == 'O') {
       printf("\033[40m\U0001F7C2 ");  // Prince noir

}

            
            else {
                if ((i + j) % 2 == 0) {
                    afficherCaseBlanche();
                } else {
                    afficherCaseMarron();
                }
            }
          
        }
        printf("\033[0m\n"); // Réinitialiser la couleur
    }
}
