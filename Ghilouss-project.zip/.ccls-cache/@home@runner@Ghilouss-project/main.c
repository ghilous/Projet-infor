#include "header.h"


int main() {
    const char* filepath ="chess.txt";
    includeFile(filepath);
    char plateau[11][11];
    Joueur joueur1, joueur2;
    Piece a,b;
    const int TAILLE_PLATEAU = 11;
    int i, j;  
    char reponse= demanderJeu();
    char jouer = 'o';
    char regle= demanderregles();
    if (reponse == 'o' || reponse == 'O') {
      while (jouer == 'o' || jouer == 'O') {
        if (regle=='o'||regle=='O'){
          printf("L'echiquier fera une taille de 11 x 11.\n");
          printf("Pour gagner la partie, un joueur devra mettre en echec et mat le roi adverse.\n");
          printf("Le jeu sera en 1V1.\n");
          printf("La notation du jeu pourra etre soit au format officiel des echecs soit en indiquant les coordonnees des pieces deplacees.\n");
          printf("Le placement initial des pieces sera choisi par les joueurs lors de la phase de preparation.\n");
          printf("o Preparation de la partie:\n");
          printf("Chaque joueur possede 40 points.\n");
          printf("Ces points permettent aux joueurs d'acheter chacun leur tour les pieces voulues et de les placer ou ils le souhaitent dans sa zone de depart (voir schema).\n");
          printf("Les rois ne sont pas achetables et seront eux places a une place predefinie sur l'echiquier.\n");
          printf("En plus des rois, des pions seront egalement presents de base sur l'echiquier (voir schema).\n");
          printf("Les pieces disponibles sont les pieces du jeu classique ainsi que deux nouvelles pieces. il y a 4 pieces de chaque partagees par les deux equipes : Reine (10 points), Cavalier (3 points), Fou (3 points), Tour (5 points).\n");
          printf("Les deux nouvelles pieces sont: le Cavalier Fou (regle de deplacement combinant le Cavalier et le Fou) (7 points), et le Prince (se deplace comme le roi mais de 2 cases) (6 points).\n");
          printf("Quiconque peut appuyer sur sur N si il ne souhaite plus acheter de piece.\n");
          printf("Ce statut sera automatiquement attribue a un joueur ayant consomme tous ses points, ou que son nombre de points restants est trop faible pour acheter une nouvelle piece.\n");
          printf("Echec et mat:en cas de mort du roi.\n");
        }
            // Initialisation du tableau d'échecs
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            plateau[i][j] = ' ';
        }
    }
            // Placement des pièces fixes
    for (i = 0; i < TAILLE_PLATEAU; i++) {
        for (j = 0; j < TAILLE_PLATEAU; j++) {
            if ((i >= 0 && i < 4) ) {
                if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    plateau[i][j] = 'B';  // Pions
                }
                if ((i == 1 && j == 5)) {
                    plateau[i][j] = 'R';  // ROIS
                }
                
        }
          if ((i > 6 && i < TAILLE_PLATEAU)) {
            if (i == j || (i + j) == (TAILLE_PLATEAU - 1)) {
                    plateau[i][j] = 'W';  // Pions
                }
                if ((i == TAILLE_PLATEAU - 2 && j == 5)) {
                    plateau[i][j] = 'L';  // ROIS
                }
    }
    }
    }
        afficherTableauEchecs(joueur1, joueur2, plateau);
        joueur1 = creationdejoueur(-1);
        joueur2 = creationdejoueur(joueur1.numcoul);
        
         deroulement_jeu(joueur1, joueur2);
        plateau[joueur1.piece.x][joueur1.piece.y]=joueur1.piece.nom;
        
        
         plateau[joueur2.piece.x][joueur2.piece.y]=joueur2.piece.nom;

        printf("Voulez-vous jouer de nouveau ? (o/n) ");
        scanf(" %c", &jouer);
    
    }
    }
    else if (reponse== 'n' || reponse=='N'){
      printf("ce n'est pas grave, la prochaine fois :/n");
    }

    return 0;
}
